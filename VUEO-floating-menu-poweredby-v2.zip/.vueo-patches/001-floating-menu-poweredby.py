from pathlib import Path

path = Path(
    "app/src/main/java/com/vueo/app/ui/VueoApp.kt"
)

if not path.exists():
    raise SystemExit(
        f"Missing live source: {path}"
    )

text = path.read_text(encoding="utf-8")
original = text

text = text.replace(
    "import androidx.compose.material3.ModalBottomSheet\n",
    "",
)

text = text.replace(
    "import androidx.compose.material3.rememberModalBottomSheetState\n",
    "",
)

popup_import = (
    "import androidx.compose.ui.window.Popup\n"
    "import androidx.compose.ui.window.PopupProperties\n"
)

if "import androidx.compose.ui.window.Popup\n" not in text:
    anchor = (
        "import androidx.compose.ui.window.DialogProperties\n"
    )

    if anchor not in text:
        raise SystemExit(
            "Popup import anchor was not found."
        )

    text = text.replace(
        anchor,
        anchor + popup_import,
        1,
    )

start_marker = (
    "@OptIn(ExperimentalMaterial3Api::class)\n"
    "@Composable\n"
    "private fun MediaActionsSheet("
)

end_marker = (
    "private const val MENU_HOLD_MS ="
)

start = text.find(start_marker)

if start < 0:
    start = text.find(
        "@Composable\n"
        "private fun MediaActionsSheet("
    )

if start < 0:
    raise SystemExit(
        "MediaActionsSheet was not found."
    )

end = text.find(
    end_marker,
    start,
)

if end < 0:
    raise SystemExit(
        "MediaActionsSheet end boundary was not found."
    )

current_menu = text[start:end]

if "Popup(" not in current_menu:
    floating_menu = '''@Composable
private fun MediaActionsSheet(
    title: String,
    subtitle: String?,
    actions: List<MediaMenuAction>,
    onDismiss: () -> Unit,
) {
    Popup(
        alignment =
            Alignment.Center,
        onDismissRequest =
            onDismiss,
        properties =
            PopupProperties(
                focusable = true,
                dismissOnBackPress = true,
                dismissOnClickOutside = true,
            ),
    ) {
        Surface(
            modifier =
                Modifier
                    .widthIn(
                        min = 264.dp,
                        max = 320.dp,
                    ),
            shape =
                RoundedCornerShape(
                    22.dp
                ),
            color =
                Color(
                    0xF5141619
                ),
            border =
                androidx.compose
                    .foundation
                    .BorderStroke(
                        width = 1.dp,
                        color =
                            Color.White
                                .copy(
                                    alpha = .10f
                                ),
                    ),
            shadowElevation =
                24.dp,
        ) {
            Column(
                modifier =
                    Modifier.padding(
                        13.dp
                    ),
                verticalArrangement =
                    Arrangement.spacedBy(
                        3.dp
                    ),
            ) {
                Row(
                    modifier =
                        Modifier.fillMaxWidth(),
                    verticalAlignment =
                        Alignment.CenterVertically,
                ) {
                    Column(
                        modifier =
                            Modifier.weight(
                                1f
                            ),
                        verticalArrangement =
                            Arrangement.spacedBy(
                                2.dp
                            ),
                    ) {
                        Text(
                            text = title,
                            color =
                                Color.White,
                            fontSize =
                                15.sp,
                            fontWeight =
                                FontWeight.Black,
                            maxLines = 1,
                            overflow =
                                TextOverflow.Ellipsis,
                        )

                        subtitle
                            ?.takeIf {
                                it.isNotBlank()
                            }
                            ?.let {
                                Text(
                                    text = it,
                                    color =
                                        VueoPalette.Muted,
                                    fontSize =
                                        10.sp,
                                    maxLines = 1,
                                    overflow =
                                        TextOverflow.Ellipsis,
                                )
                            }
                    }

                    Box(
                        modifier =
                            Modifier
                                .width(
                                    18.dp
                                )
                                .height(
                                    3.dp
                                )
                                .clip(
                                    CircleShape
                                )
                                .background(
                                    VueoPalette.Accent
                                        .copy(
                                            alpha = .80f
                                        )
                                ),
                    )
                }

                Spacer(
                    Modifier.height(
                        4.dp
                    )
                )

                actions.forEach {
                    action ->

                    val tint =
                        if (
                            action.destructive
                        ) {
                            MaterialTheme
                                .colorScheme
                                .error
                        } else {
                            VueoPalette.Accent
                        }

                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .clip(
                                    RoundedCornerShape(
                                        14.dp
                                    )
                                )
                                .clickable(
                                    onClick =
                                        action.onClick
                                )
                                .padding(
                                    horizontal =
                                        7.dp,
                                    vertical =
                                        7.dp,
                                ),
                        horizontalArrangement =
                            Arrangement.spacedBy(
                                10.dp
                            ),
                        verticalAlignment =
                            Alignment.CenterVertically,
                    ) {
                        Surface(
                            modifier =
                                Modifier.size(
                                    34.dp
                                ),
                            shape =
                                CircleShape,
                            color =
                                tint.copy(
                                    alpha = .12f
                                ),
                        ) {
                            Icon(
                                imageVector =
                                    action.icon,
                                contentDescription =
                                    null,
                                modifier =
                                    Modifier.padding(
                                        8.dp
                                    ),
                                tint = tint,
                            )
                        }

                        Text(
                            text =
                                action.label,
                            modifier =
                                Modifier.weight(
                                    1f
                                ),
                            color =
                                if (
                                    action.destructive
                                ) {
                                    MaterialTheme
                                        .colorScheme
                                        .error
                                } else {
                                    Color.White
                                        .copy(
                                            alpha = .94f
                                        )
                                },
                            fontSize =
                                if (
                                    action.destructive
                                ) {
                                    12.sp
                                } else {
                                    13.sp
                                },
                            lineHeight =
                                16.sp,
                            fontWeight =
                                FontWeight.SemiBold,
                            maxLines =
                                if (
                                    action.destructive
                                ) {
                                    2
                                } else {
                                    1
                                },
                            overflow =
                                TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

'''

    text = (
        text[:start]
        + floating_menu
        + text[end:]
    )

related_start = text.find(
    "        if (relatedItems.isNotEmpty()) {"
)

details_end = text.find(
    "@Composable\n"
    "private fun DetailsLoadingSkeleton()",
    related_start,
)

if related_start < 0 or details_end < 0:
    raise SystemExit(
        "More Like This section was not found."
    )

section = text[
    related_start:details_end
]

marker = (
    "vueo-more-like-this-attribution-bottom"
)

if marker not in section:
    attr_start = section.find(
        "                        Text(\n"
        "                            text =\n"
        "                                moreLikeThisAttribution("
    )

    if attr_start < 0:
        raise SystemExit(
            "Existing More Like This attribution was not found."
        )

    lazy_start = section.find(
        "                    LazyRow(",
        attr_start,
    )

    if lazy_start < 0:
        raise SystemExit(
            "More Like This poster row was not found."
        )

    pos = attr_start
    depth = 0
    seen_open = False
    attr_end = None

    while pos < lazy_start:
        ch = section[pos]

        if ch == "(":
            depth += 1
            seen_open = True

        elif ch == ")":
            depth -= 1

            if seen_open and depth == 0:
                end_pos = pos + 1

                while (
                    end_pos < len(section)
                    and section[end_pos] in " \t"
                ):
                    end_pos += 1

                if (
                    end_pos < len(section)
                    and section[end_pos] == "\n"
                ):
                    end_pos += 1

                attr_end = end_pos
                break

        pos += 1

    if attr_end is None:
        raise SystemExit(
            "Could not isolate old attribution block."
        )

    section = (
        section[:attr_start]
        + section[attr_end:]
    )

    lazy_start = section.find(
        "                    LazyRow("
    )

    brace_start = section.find(
        "{",
        lazy_start,
    )

    if brace_start < 0:
        raise SystemExit(
            "LazyRow opening brace was not found."
        )

    depth = 0
    lazy_end = None

    for pos in range(
        brace_start,
        len(section),
    ):
        ch = section[pos]

        if ch == "{":
            depth += 1

        elif ch == "}":
            depth -= 1

            if depth == 0:
                lazy_end = pos + 1
                break

    if lazy_end is None:
        raise SystemExit(
            "LazyRow closing brace was not found."
        )

    bottom_attr = '''

                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal =
                                        18.dp
                                ),
                        horizontalArrangement =
                            Arrangement.End,
                    ) {
                        Text(
                            text =
                                moreLikeThisAttribution(
                                    usesVueo =
                                        relatedUsesVueo,
                                    usesTmdb =
                                        relatedUsesTmdb,
                                ),
                            modifier =
                                Modifier
                                    // vueo-more-like-this-attribution-bottom
                                    .padding(
                                        top = 1.dp
                                    ),
                            color =
                                VueoPalette.Muted
                                    .copy(
                                        alpha = .68f
                                    ),
                            fontSize = 8.sp,
                            maxLines = 1,
                        )
                    }'''

    section = (
        section[:lazy_end]
        + bottom_attr
        + section[lazy_end:]
    )

    text = (
        text[:related_start]
        + section
        + text[details_end:]
    )

menu_start = text.find(
    "@Composable\n"
    "private fun MediaActionsSheet("
)

menu_end = text.find(
    "private const val MENU_HOLD_MS =",
    menu_start,
)

menu = text[
    menu_start:menu_end
]

checks = {
    "floating Popup menu":
        "Popup(" in menu,
    "outside tap dismiss":
        "dismissOnClickOutside = true" in menu,
    "bottom sheet removed":
        "ModalBottomSheet(" not in menu,
    "compact width":
        "max = 320.dp" in menu,
    "powered attribution moved":
        marker in text,
}

failed = [
    name
    for name, ok in checks.items()
    if not ok
]

if failed:
    raise SystemExit(
        "Patch verification failed: "
        + ", ".join(failed)
    )

if text == original:
    print(
        "Floating menu patch already applied."
    )
else:
    path.write_text(
        text,
        encoding="utf-8",
    )

    print(
        "Patched latest VueoApp.kt successfully."
    )
